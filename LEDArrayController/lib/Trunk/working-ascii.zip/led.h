#define POLLDELAY 10  // was 50 //USEC between polls

// TODO: make delays calculated
#define CHARDELAY  15 // was 15 // USEC between serial sends

#define LINEDELAY 200 // was 200 // USEC, loosely  based on #leds

struct strand_struct {
	unsigned int leds;	// Number of LEDs
	unsigned char *device;	// LED serial device
	int fd;		// Serial FD
	unsigned char *colors;	// Color Table
	unsigned int baud;	// Serial Baud
	unsigned int line_delay; // line delay
	unsigned int char_delay; // char delay
};

typedef struct strand_struct STRAND;


