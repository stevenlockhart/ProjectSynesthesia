#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <termios.h>
#include <fcntl.h>
#include <errno.h>

#include "led.h"


// For Main
#include <time.h>

STRAND * build_strand(int leds, char* device, int baud) {
	int i;
	int line_delay = LINEDELAY; // TODO
	int char_delay = CHARDELAY; // Calculate and remove def
    
	STRAND * t = malloc(sizeof(struct strand_struct));
	t->baud = baud;
	t->device = malloc(strlen(device));
	t->leds = leds;
	t->line_delay = line_delay;
	t->char_delay = char_delay;
	strcpy(t->device, device);
    
	if ((t->fd = open(device, O_RDWR | O_NOCTTY | O_NDELAY)) == -1) {
		printf("Device open failed: %s\n",device);
		free(t->device);
		free(t);
		return NULL; 
	}
    
	t->colors = calloc(leds * 3, sizeof(char));
	for (i = 0 ; i < leds ; i++) {
		t->colors[(i*3)] = 255; // Red
        t->colors[(i*3) + 1] = 20; // Green
        t->colors[(i*3) + 2] = 100; // Blue
	}
    
    struct termios options, oldops;
	tcgetattr(t->fd, &oldops);
    memset(&options, 0, sizeof(options));
    options.c_iflag = (IGNPAR | IGNBRK);
    options.c_oflag = 0;
    options.c_cflag = (CREAD | CLOCAL | CS8);
    options.c_lflag = 0;
    
	cfsetispeed(&options, baud);
    cfsetospeed(&options, baud);
    tcflush(t->fd, TCIOFLUSH);
    tcsetattr(t->fd, TCSANOW, &options);
    /*
    options.c_cflag &= ~PARENB;
	options.c_cflag &= ~CSTOPB;
	options.c_cflag &= ~CSIZE;
	options.c_cflag |= CS8;
    options.c_cflag |= (CLOCAL | CREAD);
    //options.c_oflag = 0;
    options.c_oflag &= ~OPOST;
    tcsetattr(t->fd, TCSAFLUSH, &options);
     */
	//printf("Strand built @ %qx\n",(int)t);
	return t;	
} 

int free_strand(STRAND * led) {
	free(led->colors);
	close(led->fd);
	free(led->device);
	free(led);
}

int strand_info(STRAND * led) {
	if (led == NULL)
		return -1;
    printf("Baud: %d\n", led->baud);
    printf("Device: %s\n", led->device);
	printf("Num. LEDs: %d\n", led->leds);
	printf("Line / Char Delay (usec): %d / %d \n",led->line_delay, led->char_delay);
}

int update_strand(STRAND * led) {
	int i;
    int b;
    unsigned char p;
    char outbuf[12];
    for (i = 0 ; i < (led->leds * 3); i++) {
        
        sprintf(outbuf, "w %02x %04x\r\n", led->colors[i], i);
        outbuf[11] = '\0';
        b = 0;
        while (outbuf[b] != 0x00) {
            p = outbuf[b];
            write(led->fd,&p,1);
            b++;
        }        
        //printf("w %02x %02x\n", i, led->colors[i]);
        //int tardbus = write(led->fd, outbuf, 12);
        printf("%s", outbuf);
		//usleep(led->char_delay);
        //tcflush(led->fd, TCIOFLUSH);
        //sleep(1);
	}
}


int main (int argc, char **argv) {
	static char device[] = "/dev/tty.usbserial-FTELSJ0N";
	STRAND * led = build_strand(120, device, 460800);
	strand_info(led);
	int i = 0;
	while (1) { // Run length
		//update_strand(led);
		int z = i; //% 30;
		for (i = 0 ; i < led->leds ; i++) {
			if (i % 2 == 0) {
				led->colors[i*3] = led->colors[(i*3) + 1] - 5;              // RED
				led->colors[(i*3) + 1] =  led->colors[(i*3) + 2] - 10;    // GREEN
				led->colors[(i*3) + 2] = led->colors[(i*3)] + 20;    // BLEW
			} else {
                led->colors[i*3] += 20;                                     // ARE
                led->colors[(i*3) + 1] -= 10;                               // GEE
                led->colors[(i*3) + 2] += 25;                               // BEE
			}
			//printf("LED %3d : %3d %3d %3d\n",i,led->colors[i*3],led->colors[(i*3) + 1], led->colors[(i*3) + 2]);
		}	
		update_strand(led);
		
		//i += 2;
		//if (i > 30)
		//	i = 0;
		//sleep(1);
        //usleep(led->line_delay);
	}
	free_strand(led);
	return 0;
}
